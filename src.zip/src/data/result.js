export const result = [0,0,0,0,0,0,0,0,0,0];
