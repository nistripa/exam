export const subjects = {
    subjects: [
      {
        id: 1,
        subject: 'Physics',
        Topics: ['Force', 'Energy']
      },
      {
        id: 2,
        subject: 'Computers',
        Topics: ['MS WOrld', 'File Management']
      },
      {
        id: 3,
        subject: 'Chemistry',
        Topics: ['Elements and Mixtures']
      },
    ]
    };
